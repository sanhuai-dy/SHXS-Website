var setufinish=document.querySelector(".setufinish")
